//BHung
export interface EmployeePassengerDTO{
    id: number;
    fullName:string;
    identifierCard:string;
    email: string;
    phoneNumber: string;
    gender: string;
    checkin: boolean;
    deptLuggagePrice: number;
    arvLuggagePrice: number;
}