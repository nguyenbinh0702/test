package vn.codegym.flightagency.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class ReportPriceDTO {
    //Thành
    private LocalDate date1;
    private LocalDate date2;
}
