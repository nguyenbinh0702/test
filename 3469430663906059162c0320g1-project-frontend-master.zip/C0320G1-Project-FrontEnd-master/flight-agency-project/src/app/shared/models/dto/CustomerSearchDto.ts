export interface CustomerSearchDto {
  fullName: string;
  address: string;
}
