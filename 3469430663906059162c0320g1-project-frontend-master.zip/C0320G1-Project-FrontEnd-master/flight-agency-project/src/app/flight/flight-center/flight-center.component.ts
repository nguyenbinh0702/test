import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flight-center',
  templateUrl: './flight-center.component.html',
  styleUrls: ['./flight-center.component.css']
})
export class FlightCenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
