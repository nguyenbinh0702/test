export interface Branch {
  id: number;
  name: string;
}
