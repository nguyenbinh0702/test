export interface FeedbackSearch {
  customerName: string;
  createDate: string;
  processStatus: boolean;
}
