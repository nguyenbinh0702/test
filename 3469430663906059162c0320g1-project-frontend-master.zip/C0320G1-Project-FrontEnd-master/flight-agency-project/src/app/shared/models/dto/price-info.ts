
export interface PriceInfo {
    passengerType: string;
    quantity: number;
    netPrice: number;
    tax: number;
    totalPrice: number;
}