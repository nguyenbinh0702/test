import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PassengerRoutingModule } from './passenger-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PassengerRoutingModule
  ]
})
export class PassengerModule { }
