// tslint:disable-next-line:class-name
export  class listCustomerDto {
  id: number;
  fullName: string;
  birthDate: string;
  gender: string;
  email: string;
  phoneNumber: string;
  address: string;
}
