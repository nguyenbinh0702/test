
export interface TransactionDetailSearchDto {
  id: number;
}
