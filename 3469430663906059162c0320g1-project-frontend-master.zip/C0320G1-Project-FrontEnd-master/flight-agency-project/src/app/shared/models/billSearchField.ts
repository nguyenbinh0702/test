export interface BillSearchFields {
    billCode: String;
    billTax: String;
    name: String;
}