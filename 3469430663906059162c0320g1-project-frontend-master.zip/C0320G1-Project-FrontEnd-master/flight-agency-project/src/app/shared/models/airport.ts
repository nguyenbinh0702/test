export interface Airport {
    [prop: string]: any;
    id: number;
    code: string;
    name: string;
    city: string;
}
