package vn.codegym.flightagency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightAgencyApplicationTests {

    @Test
    void contextLoads() {
    }

}
