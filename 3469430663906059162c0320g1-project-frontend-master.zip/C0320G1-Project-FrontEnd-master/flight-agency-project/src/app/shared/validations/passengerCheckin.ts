export  const NOTIFICATION_USER = {
  captchaErrors: [
    {code: 'required', message: 'Vui lòng nhập mã xác minh !'},
    {code: 'pattern', message: 'Mã xác minh không đúng !'}
  ]
};
