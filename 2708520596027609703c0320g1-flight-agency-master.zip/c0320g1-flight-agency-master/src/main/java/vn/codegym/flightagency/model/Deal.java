//package vn.codegym.flightagency.model;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//import javax.persistence.*;
//
//@Entity
//@Table(name = "deal")
//@Getter
//@Setter
//@NoArgsConstructor
//public class Deal {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "deal_id")
//    private Long id;
//
//    private Long quantity;
//    private Long unitPrice;
//
//
//}
