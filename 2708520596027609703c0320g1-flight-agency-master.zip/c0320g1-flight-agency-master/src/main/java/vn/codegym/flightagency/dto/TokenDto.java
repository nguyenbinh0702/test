package vn.codegym.flightagency.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//Created by: Quân
public class TokenDto {
    String value;
    String email;
    String avatarURL;
}
